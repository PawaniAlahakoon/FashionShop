/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.coursework_09;

/**
 *
 * @author DELL
 */
import java.util.*;
public class Customer_Object {

    public static final double[] price = {600.0, 800.0, 900.0, 1000.0, 1100.0, 1200.0};
    private String OrderId;
    private String CustomerNumber;
    private String Sizes;
    private int qtys;
    private int orderStatusabout;
    private double Ammount;
    
   static ArrayList<Customer_Object> CustometArraylist=new ArrayList<>();
           
    
    
    
  public Customer_Object(String  OrderId, String  CustomerNumber, String Sizes, int qtys, int orderStatusabout, double Ammount) {
        this. OrderId =  OrderId;
        this. CustomerNumber =  CustomerNumber;
        this. Sizes=  Sizes;
        this.qtys = qtys;
        this.orderStatusabout = orderStatusabout;
        this.Ammount = Ammount;
    }

    public String getOrderID() {
        return  OrderId;
    }

    public void setOrderID(String orderID) {
        this. OrderId =  OrderId;
    }

    public String getCustomerNumber() {
        return  CustomerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
        this. CustomerNumber =  CustomerNumber;
    }

    public String getSize() {
        return  Sizes;
    }

    public void setSize(String size) {
        this. Sizes =  Sizes;
    }

    public int getQty() {
        return qtys;
    }

    public void setQty(int qty) {
        this.qtys = qtys;
    }

    public int getStatus() {
        return orderStatusabout;
    }

    public void setStatus(int status) {
        this.orderStatusabout =orderStatusabout;
    }

    public double getAmount() {
        return Ammount;
    }

    public void setAmount(double amount) {
        this.Ammount = Ammount;
    }
    
}
